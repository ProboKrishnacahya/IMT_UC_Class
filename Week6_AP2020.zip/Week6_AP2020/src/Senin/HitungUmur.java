package Senin;

import java.util.Scanner;

public class HitungUmur {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Masukkan Tanggal Lahir");
        int tgl = s.nextInt();
        System.out.println("Masukkan Bulan Lahir");
        int bln = s.nextInt();
        System.out.println("Masukkan Tahun Lahir");
        int thn = s.nextInt();
        System.out.println("Masukkan Tanggal Sekarang");
        int tglSkr = s.nextInt();
        System.out.println("Masukkan Bulan Sekarang");
        int blnSkr = s.nextInt();
        System.out.println("Masukkan Tahun Sekarang");
        int thnSkr = s.nextInt();
//     
        boolean isSkrKabisat;
        if (thnSkr % 400 == 0) {
            isSkrKabisat = true;
        } else if (thnSkr % 100 == 0) {
            isSkrKabisat = false;
        } else if (thnSkr % 4 == 0) {
            isSkrKabisat = true;
        } else {
            isSkrKabisat = false;
        }

        int nBlnSkr = 0;
        //bulan berjumlah hari 31 adalah bulan ke-1, 3, 5, 7, 8, 10, 12
        //perhatikan bahwa hingga bulan ke-7, bulan berjumlah 31 adalah bulan ganjil, 
        //sedangkan setelah bulan 7, adalah bulan genap.
        if (blnSkr <= 7) {

            if (blnSkr % 2 == 0) {
                //pada bulan genap, ada februari, yaitu bulan ke-2
                if (blnSkr != 2) {
                    nBlnSkr = 30;
                } else {
                    //jika februari, maka dilihat apakah tahun itu adl tahun kabisat
                    if (isSkrKabisat) {
                        nBlnSkr = 29;
                    } else {
                        nBlnSkr = 28;
                    }
                }
            } else {
                nBlnSkr = 31;
            }
        } else {
            if (blnSkr % 2 == 0) {
                nBlnSkr = 31;
            } else {
                nBlnSkr = 30;
            }
        }
//        

        //hitung umur
        int umurThn = thnSkr - thn;//by default ini adalah perhitungan umur dalam tahun
        int umurBln = 0;
        int umurHari = 0;
        //sekarang kita cek apakah sudah ultah ?
        //1. bln lahir > bln skr, maka belom ultah
        if (bln > blnSkr) {
            //jika belom ultah maka, umur thaun dikurangi 1
            umurThn--;
            //umur bulan adalah 12 bulan dikurangi selisih bulan lahir dengan bulan sekarang
            umurBln = 12 - (bln - blnSkr);
            //jika tanggal lahir lebih besar dari tanggal sekarang
            //artinya umumr bulannya belom pas 1 bulan, sehingga
            if (tgl > tglSkr) {
                //umur bulang dikurangi 1
                umurBln--;
                //hitung umur harinya, yaitu selisih jumlah hari di bulan itu
                //dengan selisih antara tanggal lahir dan tanggal sekarang)
                umurHari = nBlnSkr - (tgl - tglSkr);
            } else { // jika tnggal lahir lebih kecil sama dengan tanggal sekarang
                //hitung selisih harinya
                umurHari = tglSkr - tgl;
            }
        } else if (bln == blnSkr) {//jika bulan sama
            //maka tingga cek tanggal
            //jika tanggal lahir lebih besar dari tangga skr, maka belum ultah
            if (tgl > tglSkr) {
                // umur tahun kurang 1
                umurThn--;
                //umur bulan masih 11 bulan
                umurBln = 11;
                //umur hari adalah sama dengan di atas
                umurHari = nBlnSkr - (tgl - tglSkr);
            } else if (tgl < tglSkr) {
                //jika tanggal lahir lebih kecl dari tanggal sekarang
                //maka hitung selisih harinya
                umurHari = tglSkr - tgl;
            } else {
                System.out.println("Happy Birthday!!");
            }
        } else {
            //jika bulan lahir lebih kecil dari bulan skr, maka sudah ultah
            //hitung umur bulan, ditambah satu, karena bulan start dari 1 bukan dari 9
            umurBln = blnSkr - bln + 1;
            //jika tanggal lahir lebih besar dari tanggal sekarang
            //artinya umumr bulannya belom pas 1 bulan, sehingga
            if (tgl > tglSkr) {
                //umur bulang dikurangi 1
                umurBln--;
                //hitung umur harinya, yaitu selisih jumlah hari di bulan itu
                //dengan selisih antara tanggal lahir dan tanggal sekarang)
                umurHari = nBlnSkr - (tgl - tglSkr);
            } else { // jika tnggal lahir lebih kecil sama dengan tanggal sekarang
                //hitung selisih harinya
                umurHari = tglSkr - tgl;
            }
        }

        System.out.println("Umur anda adalah " + umurThn + " tahun " + umurBln + " bulan " + umurHari + " hari");

    }
}
