/*
Program Kalkulator
By Krishna
 */

// Contoh comment

package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */

public class Soal0 {
    
    // Semua code program akan dituliskan disini
    
    // Buatlah program untuk melakukan penjumlahan
    
    public static void main(String[] args) {
        // Code program yang akan dijalankan
        
        Scanner scan = new Scanner(System.in); // Untuk menerima input
       
        // Membuat variabel
        // Deklarasi & inisialisasi
        int angka1 = 0;
        int angka2 = 10;
        int hasil = 99;
        
        int number1, number2, result = 0;
        
        String nama  = "Halo, nama saya Krishna"; // Kalimat
        boolean coba = true;
        
        char karakter = '.'; // Karakter
        
        float angkaKoma = (float) 1.5;
        double angkaDouble = 4.12345;
        
        // Input
        System.out.println("Masukkan angka pertama");
        angka1 = scan.nextInt ();
        
        System.out.println("Masukkan angka kedua");
        angka2 = scan.nextInt();
        
        // Proses
        hasil = angka1 + angka2; // Penjumlahan
        hasil = angka1 - angka2; // Pengurangan
        hasil = angka1 * angka2; // Perkalian
        hasil = angka1 / angka2; // Pembagian
        hasil = angka1 % angka2; // mod
        double hasilAkar = Math.sqrt (9); // Akar hasil 3
        double pangkat = Math.pow(2, 5); // Pangkat hasil 32
        
        // Output
        System.out.println("Hasil penjumlahan" + angka1 + "dan" + angka2 + "hasil");
        
//        System.out.println("Hasil pengukuran = " + hasil + "cm");
//        
//        int x = 0;
//        System.out.println("Nilai x = " + x);
        
    }
}
