package com.elflin.prog_tech;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import model.Barang;

public class BarangRVAdapter extends RecyclerView.Adapter<BarangRVAdapter.BarangViewHolder> {

    private ArrayList<Barang> listBarang;
    protected OnCardListener cardListener;

    public BarangRVAdapter(ArrayList<Barang> listBarang, OnCardListener cardListener) {
        this.cardListener = cardListener;
        this.listBarang = listBarang;
    }

    @NonNull
    @Override
    public BarangViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.card_barang, parent, false);
        return new BarangViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BarangViewHolder holder, int position) {
        holder.card_nama_item.setText(listBarang.get(position).getNama());
        holder.card_jumlah_item.setText(String.valueOf(listBarang.get(position).getJumlah()));
    }

    @Override
    public int getItemCount() {
        return listBarang.size();
    }

    public class BarangViewHolder extends RecyclerView.ViewHolder {

        private TextView card_nama_item, card_jumlah_item;
        private ImageView card_image_item;

        public BarangViewHolder(@NonNull View itemView) {
            super(itemView);
            card_nama_item = itemView.findViewById(R.id.card_nama_item);
            card_jumlah_item = itemView.findViewById(R.id.card_jumlah_item);
            card_image_item = itemView.findViewById(R.id.card_image_item);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cardListener.onCardClick(getAdapterPosition());
                }
            });
        }
    }
}
