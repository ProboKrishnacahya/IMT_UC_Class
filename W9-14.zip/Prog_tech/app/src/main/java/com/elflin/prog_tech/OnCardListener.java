package com.elflin.prog_tech;

public interface OnCardListener {
    void onCardClick(int position);
}
