/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Week13_AP2020;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class NilaiMatKul {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int jumlahMahasiswa = 0;

        System.out.print("Masukkan jumlah mahasiswa : ");
        jumlahMahasiswa = scan.nextInt();

        String data[][] = new String[jumlahMahasiswa][5];

        /*
        
        Mapping array [i][j]
        i = jumlah mahasiswa
        j = atribut
        
        j
        index 0 adalah Nama
        index 1 adalah Tugas
        index 2 adalah UTS
        index 3 adalah UAS
        index 4 adalah Rata-rata
        
         */
        // Input
        for (int i = 0; i < data.length; i++) {
            System.out.println("=====================");
            System.out.print("Input Nama Mahasiswa " + (i + 1) + " : ");
            data[i][0] = scan.next() + scan.nextLine();

            System.out.print("Input Tugas Mahasiswa " + (i + 1) + " : ");
            data[i][1] = scan.next() + scan.nextLine();

            System.out.print("Input UTS Mahasiswa " + (i + 1) + " : ");
            data[i][2] = scan.next() + scan.nextLine();

            System.out.print("Input UAS Mahasiswa " + (i + 1) + " : ");
            data[i][3] = scan.next() + scan.nextLine();
        }

        // Proses
        for (int i = 0; i < data.length; i++) {
            double Tugas = Double.parseDouble(data[i][1]);
            double UTS = Double.parseDouble(data[i][2]);
            double UAS = Double.parseDouble(data[i][3]);
            double Rata_rata = (Tugas + UTS + UAS) / 3;

            data[i][4] = String.valueOf(Rata_rata);
        }
        
        // Output
        System.out.println("Nama \t Tugas \t UTS \t UAS \t Rata-rata");
        for (int i =0; i<data.length; i++){
            System.out.println(data[i][0]+ " \t " + data[i][1] + " \t " + data[i][2] + " \t " + data[i][3] + " \t " + data[i][4] + " \t ");
        }
    }
}
