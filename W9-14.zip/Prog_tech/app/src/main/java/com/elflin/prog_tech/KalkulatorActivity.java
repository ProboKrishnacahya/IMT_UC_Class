package com.elflin.prog_tech;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;

public class KalkulatorActivity extends AppCompatActivity {

    private TextInputLayout kalkulator_display;
    private Button kalkulator_1, kalkulator_2, kalkulator_3, kalkulator_4, kalkulator_5, kalkulator_6
            , kalkulator_7, kalkulator_8, kalkulator_9, kalkulator_0, kalkulator_tambah, kalkulator_kurang
            , kalkulator_kali, kalkulator_bagi, kalkulator_clear, kalkulator_samadengan;

    private double total, angkaDisplay;
    private char operator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kalkulator);
        initview();
    }

    private void initview() {
        kalkulator_display = findViewById(R.id.kalkulator_display);
        kalkulator_1 = findViewById(R.id.kalkulator_1);
        kalkulator_2 = findViewById(R.id.kalkulator_2);
        kalkulator_3 = findViewById(R.id.kalkulator_3);
        kalkulator_4 = findViewById(R.id.kalkulator_4);
        kalkulator_5 = findViewById(R.id.kalkulator_5);
        kalkulator_6 = findViewById(R.id.kalkulator_6);
        kalkulator_7 = findViewById(R.id.kalkulator_7);
        kalkulator_8 = findViewById(R.id.kalkulator_8);
        kalkulator_9 = findViewById(R.id.kalkulator_9);
        kalkulator_0 = findViewById(R.id.kalkulator_0);
        kalkulator_tambah = findViewById(R.id.kalkulator_tambah);
        kalkulator_kurang = findViewById(R.id.kalkulator_kurang);
        kalkulator_kali = findViewById(R.id.kalkulator_kali);
        kalkulator_bagi = findViewById(R.id.kalkulator_bagi);
        kalkulator_clear = findViewById(R.id.kalkulator_clear);
        kalkulator_samadengan = findViewById(R.id.kalkulator_samadengan);
    }
}