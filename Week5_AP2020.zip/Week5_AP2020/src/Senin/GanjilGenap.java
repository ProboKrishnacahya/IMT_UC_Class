/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class GanjilGenap {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        // Preparation
        int input = 0;

        // Input
        System.out.println("Masukkan nilai");
        input = s.nextInt();

        // Input nya 70
        if (input > 80) {
            System.out.println("A");
        } else if (input > 70) {
            System.out.println("B");
        } else {
            System.out.println("C");
        }
    }

}
