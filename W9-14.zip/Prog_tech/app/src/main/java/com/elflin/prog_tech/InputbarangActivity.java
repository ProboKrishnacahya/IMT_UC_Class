package com.elflin.prog_tech;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputLayout;

import java.util.HashMap;
import java.util.Map;

import model.Barang;

public class InputbarangActivity extends AppCompatActivity {

    private TextInputLayout inputbarang_nama, inputbarang_jumlah;
    private Button inputbarang_addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inputbarang);
        initView();
        setListener();
    }

    private void setListener() {
        inputbarang_addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama = inputbarang_nama.getEditText().getText().toString().trim();
                int jumlah = Integer.parseInt(inputbarang_jumlah.getEditText().getText().toString().trim());
                Barang temp = new Barang(nama, jumlah);

                postData(temp);
            }
        });
    }

    private void postData(Barang temp){
        String url = "http://10.0.2.103/progtech_webservice/CreateBarang.php";
        RequestQueue myRequest = Volley.newRequestQueue(this);

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Intent intent = new Intent(getBaseContext(), RecyclerviewActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> data = new HashMap<>();
                data.put("nama", temp.getNama());
                data.put("jumlah", String.valueOf(temp.getJumlah()));

                return data;
            }
        };

        myRequest.add(request);
    }

    private void initView() {
        inputbarang_nama = findViewById(R.id.inputbarang_nama);
        inputbarang_jumlah = findViewById(R.id.inputbarang_jumlah);
        inputbarang_addButton = findViewById(R.id.inputbarang_addButton);
    }
}