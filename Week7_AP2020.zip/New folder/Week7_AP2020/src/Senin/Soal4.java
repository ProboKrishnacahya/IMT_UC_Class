/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Soal4 {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        System.out.println("Bangun");
        System.out.println("1. Persegi panjang");
        System.out.println("2. Lingkaran");
        System.out.println("Pilih");

        int Pilih = s.nextInt();

        switch (Pilih) {
            case 1:
                System.out.println("Panjang : ");
                int p = s.nextInt();
                System.out.println("Lebar : ");
                int l = s.nextInt();
                int L = p * l;
                System.out.println("Luas = " + L);
                break;

            case 2:
                System.out.println("Lebar");
                int r = s.nextInt();
                double LLingkaran = 
        }
    }
}
