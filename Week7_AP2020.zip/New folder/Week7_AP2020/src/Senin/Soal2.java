/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Soal2 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int ESale1;
        int ESale2;
        int ESale3;
        int ESale4;
        int Total;
        double Komisi;

        System.out.println("Penjualan Sales 1");
        ESale1 = scan.nextInt();

        System.out.println("Penjualan Sales 2");
        ESale2 = scan.nextInt();

        System.out.println("Penjualan Sales 3");
        ESale3 = scan.nextInt();

        System.out.println("Penjualan Sales 4");
        ESale4 = scan.nextInt();

        Total = ESale1 + ESale2 + ESale3 + ESale4;
        System.out.println("Total penjualan = " + Total);

        // Cari komisi
        if ((double) ESale1 / Total <= 0.05) {
            Komisi = 0;
        } else if ((double) ESale1 / Total <= 0.2) {
            Komisi = 0.05 * Total;
        } else if ((double) ESale1 / Total <= 0.4) {
            Komisi = 0.1 * Total;
        } else {
            Komisi = 0.15 * Total;
        }
        System.out.println("Komisi Employee 1 = " + Komisi);
        Komisi = 0;

        if ((double) ESale2 / Total <= 0.05) {
            Komisi = 0;
        } else if ((double) ESale2 / Total <= 0.2) {
            Komisi = 0.05 * Total;
        } else if ((double) ESale2 / Total <= 0.4) {
            Komisi = 0.1 * Total;
        } else {
            Komisi = 0.15 * Total;
        }
        System.out.println("Komisi Employee 2 = " + Komisi);
        Komisi = 0;

        if ((double) ESale3 / Total <= 0.05) {
            Komisi = 0;
        } else if ((double) ESale3 / Total <= 0.2) {
            Komisi = 0.05 * Total;
        } else if ((double) ESale3 / Total <= 0.4) {
            Komisi = 0.1 * Total;
        } else {
            Komisi = 0.15 * Total;
        }
        System.out.println("Komisi Employee 3 = " + Komisi);
        Komisi = 0;

        if ((double) ESale4 / Total <= 0.05) {
            Komisi = 0;
        } else if ((double) ESale4 / Total <= 0.2) {
            Komisi = 0.05 * Total;
        } else if ((double) ESale4 / Total <= 0.4) {
            Komisi = 0.1 * Total;
        } else {
            Komisi = 0.15 * Total;
        }
        System.out.println("Komisi Employee 4 = " + Komisi);
        Komisi = 0;
    }
}
