/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Week12_AP2020;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Soal1 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        // Minta inputan untuk panjang Array dari user
        System.out.print("Masukkan panjang Array : ");
        int PanjangArray = scan.nextInt();

        // Deklarasi dan inisialisasi menggunakan panjang Array dari inputan user
        String arrayString[] = new String[PanjangArray];
        System.out.println("Panjang Array adalah " + arrayString.length);

        System.out.println("\n");

        // Input
        for (int i = 0; i < arrayString.length; i++) {
            System.out.println("Masukkan nilai Array " + i + " = ");
            arrayString[i] = scan.next() + scan.nextLine();
        }

        System.out.println("\n");

        // Proses
        System.out.println("\n");

        // Output
        for (int i = 0; i < arrayString.length; i++) {
            System.out.println("Nilai Array " + i + " adalah " + arrayString[i]);
        }
    }
}
