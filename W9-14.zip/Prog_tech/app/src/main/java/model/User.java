package model;


import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable {

    private String nama, alamat, jenisKelamin, email, password;

    public User() {
        this.nama = "";
        this.alamat = "";
        this.jenisKelamin = "";
        this.email = "";
        this.password = "";
    }

    public User(String nama, String alamat, String jenisKelamin, String email, String password) {
        this.nama = nama;
        this.alamat = alamat;
        this.jenisKelamin = jenisKelamin;
        this.email = email;
        this.password = password;
    }

    protected User(Parcel in) {
        nama = in.readString();
        alamat = in.readString();
        jenisKelamin = in.readString();
        email = in.readString();
        password = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public void setJenisKelamin(String jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nama);
        dest.writeString(alamat);
        dest.writeString(jenisKelamin);
        dest.writeString(email);
        dest.writeString(password);
    }
}
