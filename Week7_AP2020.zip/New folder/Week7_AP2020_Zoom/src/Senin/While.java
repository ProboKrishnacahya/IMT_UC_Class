/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class While {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        int Total = 1;
        int Hasil = 1;
        int Angka1 = 0;
        int Angka2 = 0;
        int Faktorial = 0;
        
        int Prima = 0;
        int Count = 0;
        String Menu1 = "";

//        do {
//            System.out.println("Menu");
//            System.out.println("A. Penjumlahan");
//            System.out.println("B. Pengurangan");
//            System.out.println("C. Faktorial");
//            System.out.println("Z. Keluar");
//            Menu = s.nextInt();
//
//            if (Menu1.equalsIgnoreCase("A")) {
//                System.out.println("Masukkan angka 1 : ");
//                Angka1 = s.nextInt();
//                System.out.println("Masukkan angka 2 : ");
//                Angka2 = s.nextInt();
//
//                Total = Angka1 + Angka2;
//                System.out.println("Total penjumlahan = " + Total);
//            } else if (Menu1.equalsIgnoreCase("B")) {
//                System.out.println("Masukkan angka 1 : ");
//                Angka1 = s.nextInt();
//                System.out.println("Masukkan angka 2 : ");
//                Angka2 = s.nextInt();
//
//                Total = Angka1 - Angka2;
//                System.out.println("Total pengurangan = " + Total);
//            } else {
//                System.out.println("Menu tidak tersedia");
//            }
//        } while (Menu != 0); // } while (Menu <= 2 && Menu >=0);
        //        int menu = 1;
      
        while (!Menu1.equalsIgnoreCase("Z")) {   // x != 0
            System.out.println("Menu");
            System.out.println("A. Penjumlahan");
            System.out.println("B. Pengurangan");
            System.out.println("C. Faktorial");
            System.out.println("D. Bilangan prima");
            System.out.println("Z. Keluar");
            System.out.print("Pilih : ");
            Menu1 = s.next() + s.nextLine();

            if (Menu1.equalsIgnoreCase("A")) {
                System.out.print("Masukkan angka 1: ");
                Angka1 = s.nextInt();
                System.out.print("Masukkan angka 2: ");
                Angka2 = s.nextInt();

                Total = Angka1 + Angka2;
                System.out.println("Total penjumlahan = " + Total);
            } else if (Menu1.equalsIgnoreCase("B")) {
                System.out.print("Masukkan angka 1: ");
                Angka1 = s.nextInt();
                System.out.print("Masukkan angka 2: ");
                Angka2 = s.nextInt();

                Total = Angka1 - Angka2;
                System.out.println("Total pengurangan = " + Total);
            } else if (Menu1.equalsIgnoreCase("C")) {
                System.out.print("Masukkan angka faktorial = ");
                Faktorial = s.nextInt();
                Hasil = 1;
                do {
                    Hasil = Hasil * Faktorial;
                    Faktorial--;
                } while (Faktorial > 0);

                System.out.println("Hasil faktorial adalah: " + Hasil);
            } else if (Menu1.equalsIgnoreCase("D")) {
                System.out.print("Bilangan = ");
                Prima = s.nextInt();
                
                Total = Prima;
                Count = 0;
                              
                while(Prima > 0){                    
                    if (Total % Prima == 0){
                        Count++;
                    }
                    Prima --;
                }
                
                if(Count == 2){
                    System.out.println("bilangan prima");
                }else{
                    System.out.println("bukan bilangan prima");
                }    
            }
        }
    }

}
