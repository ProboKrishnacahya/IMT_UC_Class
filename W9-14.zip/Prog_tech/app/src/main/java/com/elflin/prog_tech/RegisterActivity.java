package com.elflin.prog_tech;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;

import com.google.android.material.textfield.TextInputLayout;

import model.User;

public class RegisterActivity extends AppCompatActivity {

    private ImageView Register_imageView_back;
    private TextInputLayout register_textInput_nama, register_textInput_alamat, register_textInput_email, register_textInput_password;
    private Button Register_button_Register;
    private RadioGroup register_radio_jenisKelamin;
    private String jenisKelamin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Register_imageView_back = findViewById(R.id.Register_imageView_back);
        register_textInput_nama = findViewById(R.id.register_textInput_nama);
        register_textInput_alamat = findViewById(R.id.register_textInput_alamat);
        register_textInput_email = findViewById(R.id.Register_textInput_email);
        register_textInput_password = findViewById(R.id.Register_textInput_password);
        Register_button_Register = findViewById(R.id.Register_button_Register);
        register_radio_jenisKelamin = findViewById(R.id.register_radio_jenisKelamin);
        jenisKelamin = "";

        register_radio_jenisKelamin.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioButton_laki){
                    jenisKelamin = "Laki-laki";
                }else if (checkedId == R.id.radioButton_perempuan){
                    jenisKelamin = "Perempuan";
                }
            }
        });

        Register_button_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama = register_textInput_nama.getEditText().getText().toString().trim();
                String alamat = register_textInput_alamat.getEditText().getText().toString().trim();
                String email = register_textInput_email.getEditText().getText().toString().trim();
                String password = register_textInput_password.getEditText().getText().toString().trim();
                if (nama.isEmpty()){
                    register_textInput_nama.setError("Please fill the name column");
                }else{
                    register_textInput_nama.setError("");
                }

                if (alamat.isEmpty()){
                    register_textInput_alamat.setError("Please fill the alamat column");
                }else{
                    register_textInput_alamat.setError("");
                }

                if (email.isEmpty()){
                    register_textInput_email.setError("Please fill the email column");
                }else{
                    register_textInput_email.setError("");
                }

                if (password.isEmpty()){
                    register_textInput_password.setError("Please fill the password column");
                }else{
                    register_textInput_password.setError("");
                }

                // Kalau semua terpenuhi baru jalan
                if (!jenisKelamin.isEmpty() && !nama.isEmpty() && !alamat.isEmpty() && !email.isEmpty() && !password.isEmpty()){
                    // Cara pertama
//                    Intent intent = new Intent(getBaseContext(), HomeActivity.class);
//                    intent.putExtra("IDnama", nama);
//                    intent.putExtra("IDalamat", alamat);
//                    intent.putExtra("IDjeniskelamin", jenisKelamin);
//                    intent.putExtra("IDemail", email);
//                    intent.putExtra("IDpassword", password);
//                    startActivity(intent);

                    // Cara kedua
                    Intent intent = new Intent(getBaseContext(), HomeActivity.class);
                    User user = new User(nama, alamat, jenisKelamin, email, password);
                    intent.putExtra("IDuser", user);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }
            }
        });

        Register_imageView_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}