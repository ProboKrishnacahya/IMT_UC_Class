/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Week12_AP2020;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Soal2 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        // Deklarasi
        int total = 0;

        // Input
        System.out.print("Masukkan panjang array : ");
        int panjangArray = scan.nextInt();

        int listAngka[] = new int[panjangArray];

        for (int i = 0; i < listAngka.length; i++) {
            System.out.print("Masukkan angka pada index " + i + " = ");
            listAngka[i] = scan.nextInt();
        }

        // Proses
        for (int i = 0; i < listAngka.length; i++) {
            total += listAngka[i];
        }

        // Output
        System.out.println("Total nilai pada array adalah " + total);
    }
}
