package com.elflin.prog_tech;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import model.Barang;

public class RecyclerviewActivity extends AppCompatActivity implements OnCardListener{

    private RecyclerView recyclerView_recyclerView;
    private ArrayList<Barang> dataBarang;
    private BarangRVAdapter adapter;
    private FloatingActionButton recyclerView_FAB_add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclerview);
        initView();
        setupRecyclerView();
        loadDataDB();
//        addDummyData();
        setListener();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1){
            if (resultCode == 200){
                Barang barangBaru = data.getParcelableExtra("barangBaru");
                dataBarang.add(barangBaru);
                adapter.notifyDataSetChanged();
            }
        }
    }

    private void setListener() {
        recyclerView_FAB_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), InputbarangActivity.class);
                startActivity(intent);
            }
        });
    }

//    private void addDummyData() {
//        dataBarang.add(new Barang("Meja Belajar", 100));
//        dataBarang.add(new Barang("Kursi Belajar", 50));
//        dataBarang.add(new Barang("TV", 150));
//        dataBarang.add(new Barang("Laptop", 30));
//        adapter.notifyDataSetChanged();
//    }
    private void loadDataDB(){
        String url = "http://10.0.2.103/progtech_webservice/ReadAllBarang.php";
        RequestQueue myQueue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonBarang = response.getJSONArray("barang");
                            for(int i = 0; i < jsonBarang.length(); i++){
                                JSONObject objBarang = jsonBarang.getJSONObject(i);
                                Barang barangBaru = new Barang();
                                barangBaru.setId(objBarang.getInt("id"));
                                barangBaru.setNama(objBarang.getString("nama"));
                                barangBaru.setImage_path(objBarang.getString("image_path"));
                                barangBaru.setJumlah(objBarang.getInt("jumlah"));
                                barangBaru.setCreated(objBarang.getString("created"));
                                dataBarang.add(barangBaru);
                            }
                            adapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }
        );

        myQueue.add(request);
    }


    private void setupRecyclerView() {
        RecyclerView.LayoutManager manager = new LinearLayoutManager(getBaseContext());
        recyclerView_recyclerView.setLayoutManager(manager);
        recyclerView_recyclerView.setAdapter(adapter);
    }

    private void initView() {
        recyclerView_recyclerView = findViewById(R.id.recyclerView_recyclerView);
        dataBarang = new ArrayList<Barang>();
        adapter = new BarangRVAdapter(dataBarang, this);
        recyclerView_FAB_add = findViewById(R.id.recyclerView_FAB_add);
    }

    @Override
    public void onCardClick(int position) {
        int id = dataBarang.get(position).getId();
        Intent intent = new Intent(getBaseContext(), DetailbarangActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }
}