/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Week12_AP2020;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Soal3 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int input;
        int index = -1;

        System.out.print("Masukkan panjang Array = ");
        int PanjangArray = scan.nextInt();

        int angka[] = new int[PanjangArray];

        for (int i = 0; i < angka.length; i++) {
            System.out.println("Masukkan nilai Array : ");
            angka[i] = scan.nextInt();
        }
        System.out.println("Angka yang ingin dicari : ");
        int x = scan.nextInt();

        for (int j = 0; j < angka.length; j++) {
            if (x == angka[j]) {
                index = j;
            }
        }
        if (index == -1) {
            System.out.println("Angka tidak ditemukan");
        } else {
            System.out.println("Angka ditemukan pada index ke = " + index);
        }
    }
}
