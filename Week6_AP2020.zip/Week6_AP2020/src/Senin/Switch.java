package Senin;

import java.util.Scanner;

public class Switch {

    public static void main(String[] args) {

        int itemStr = 0
        String nama = "";
        switch (item) {
            case 1:
                itemStr = "Roti";
                harga = 10000;
                break;
            case 2:
                itemStr = "Susu";
                harga = 12500;
                break;
            case 3:
                itemStr = "Kopi";
                harga = 15000;
                break;
            default:
                System.out.println("Salah input!!");
        }
        System.out.println("Masukkan jumlah " + itemStr );
    }
}
