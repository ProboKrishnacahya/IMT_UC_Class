/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class TrialString {

    public static void main(String[] args) {

        String pertama = "Saya";
        String kedua = "Makan";

        // Concat
//      String ketiga = pertama + kedua;
        System.out.println(pertama + " " + kedua + 1);

        String keempat = "Saya";

// Equals
        System.out.println(pertama.equals("Saya"));
// EqualsIgnoreCase
        System.out.println(pertama.equalsIgnoreCase(keempat));

        String kelima = "50";
        String keenam = "20";

        int x = Integer.parseInt(kelima);
        float y = Float.parseFloat(keenam);
        double z = Double.parseDouble(kelima);

        System.out.println(kelima + keenam); // Concat
        System.out.println(x + y); // Perhitungan matematika

        System.out.println(keempat.toUpperCase());
        System.out.println(kedua.toLowerCase());

        System.out.println(kedua.replace('a', 'o'));
        System.out.println(kedua.replace("ak", "om"));

        String text = "Saya Makan Nasi Bakar";

        System.out.println(text.length());

        for (int i = 0; i < text.length(); i++);
//        if (text.charAt(i) == 'a' || text.charAt(i) == 'A') {
//        }

        if (String.valueOf(text.charAt(i)).equalsIgnoreCase("A")) {
            System.out.print(i + "");
        }
    }

    char arrayChar[] = text.toCharArray();
    
    for (int i=0; i <text.length(); i++){
            System.out.println(arrayChar [i]);
}
    String text1 = "Saya Makan Nasi Bakar"; // String
    for (int i=0; i<text1.length();i++){
    char temp = text1.charAt(i);
    
    if (temp >= 65 && temp <= 90){ // Huruf besar
        String temp1 = String.valueOf (temp).toLowerCase();
        haloKata = haloKata + temp1;
        System.out.println(temp1);
    }else{ // Huruf kecil
        String temp2 = String.valueOf(temp).toUpperCase();
        System.out.println(temp2);
    }
            }
}
