/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Week13_AP2020;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 *
 * @author DELL
 */
public class NewClass {

    public static void main(String[] args) throws IOException {
        FileWriter fw = null;
        BufferedWriter bw = null;
//        try {
            fw = new FileWriter("cobaa.txt");
            bw = new BufferedWriter(fw);
            bw.write("Berinvestasi Memang Berisiko, TETAPI Tidak Berinvestasi Jauh Lebih Berisiko!");
            bw.newLine();
            bw.write("Salam,");
            bw.newLine();
            bw.write("Krishna");
//            System.out.println("Selesai");
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                if (bw != null) {
//                    bw.close();
//                }
//
//                if (fw != null) {
//                    fw.close();
//                }
//            } catch (IOException iex) {
//                iex.printStackTrace();
//            }
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String nama;
        String alamat;

        try {
            System.out.print("Masukkan nama anda : "); // melakukan input nama
            nama = br.readLine();
            System.out.print("Masukkan alamat anda : "); // melakukan input nama
            alamat = br.readLine();
            System.out.println("===============================");
            System.out.println("Nama anda : " + nama); // menampilkan pesan nama
            System.out.println("Alamat anda : " + alamat); // menampilkan pesan alamat
        } catch (IOException eox) // menangkap kesalahan
        {
            System.out.println(eox);
        }
    }
}
