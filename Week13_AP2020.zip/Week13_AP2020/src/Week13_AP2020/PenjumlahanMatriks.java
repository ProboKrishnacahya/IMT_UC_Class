package Week13_AP2020;

import java.util.Scanner;

public class PenjumlahanMatriks {

    public static void main(String[] args) {

        // Deklarasi & inisialisasi
        Scanner scan = new Scanner(System.in);

        int matriks1[][] = new int[3][3]; // indeksnya 0, 1, 2 dengan jumlah 3
        int matriks2[][] = new int[3][3];
        int total[][] = new int[3][3];

        // Matriks 1
        System.out.println("Masukkan nilai matriks 1");
        for (int i = 0; i < matriks1.length; i++) { // For untuk indeks pertama (i)
            for (int j = 0; j < matriks1[i].length; j++) { // For untuk indeks kedua (j)
                System.out.print("Nilai matriks1 (" + i + "," + j + ") = ");
                matriks1[i][j] = scan.nextInt();
            }
        }

        // Matriks 2
        System.out.println("\n\nMasukkan nilai matriks 2");
        for (int i = 0; i < matriks2.length; i++) {
            for (int j = 0; j < matriks2[i].length; j++) {
                System.out.print("Nilai matriks 2 (" + i + "," + j + ") = ");
                matriks2[i][j] = scan.nextInt();
            }
        }

        // Proses menghitung total
        // total = matriks1[i][j] + matriks2[i][j]
        for (int i = 0; i < matriks2.length; i++) {
            for (int j = 0; j < matriks2.length; j++) {
                total[i][j] = matriks1[i][j] + matriks2[i][j];
            }
        }

        // Output
        for (int i = 0; i < 3; i++) { // i kebawah
            // Cetak matriks 1
            for (int j = 0; j < 3; j++) { // j kesamping
                System.out.print(matriks1[i][j]+"\t");
            }

            // Cetak + atau spasi
            if (i == 1) {
                System.out.println("\t+\t");
            } else {
                System.out.println("\t \t");
            }

            // Cetak matriks 2
            for (int j = 0; j < 3; j++) {
                System.out.print(matriks2[i][j] + "\t");
            }

            // Cetak sama dengan 
            if (i == 1) {
                System.out.println("\t=\t");
            }else{
                System.out.println("\t \t");
            }

            // Cetak total
            for (int j = 0; j < 3; j++) {
                System.out.print(total[i][j]);
            }
            
            System.out.println("");
        }
    }
}
