/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class MintaInput {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Jumlah input : ");
        int Input = scan.nextInt();
        int Jumlah = 0;
//        int Counter = 1;
//        while (Counter <= Input) {
//            System.out.print("Angka : ");
//            int Angka = scan.nextInt();
//            Jumlah = Jumlah + Angka;
//            Counter++;
//        }
        for (int Counter = 1; Counter <= Input; Counter++) {
            System.out.print("Angka : ");
            int Angka = scan.nextInt();
            Jumlah = Jumlah + Angka;
        }
        for (int Counter = 0; Counter <= 100; Counter++) {
        }
        System.out.println("Total Jumlah " + Jumlah);

    }
}
