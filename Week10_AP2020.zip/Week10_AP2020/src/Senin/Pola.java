/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Pola {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Input : ");

        int Input = scan.nextInt();

        for (int j = 1; j <= Input; j++) {
            for (int i = 2; i <= Input; i++) {
                System.out.print("+");
            }
            System.out.println("+"); // Ganti baris
//        for (int j = 1; j <= Input; j++) {
//
//            for (int k = 1; k <= Input; k++) {
//                if (k <= (Input - j + 1)) {
//                    System.out.print("+");
//                } else {
//                    System.out.print(" ");
//                }
//            }
//            for (int i = 1; i <= Input; i++) {
//                if (i < j) {
//                    System.out.print(" ");
//                } else {
//                    System.out.print("+");
//                }
//            }
//            System.out.println(""); // Ganti baris
        }
    }
}
