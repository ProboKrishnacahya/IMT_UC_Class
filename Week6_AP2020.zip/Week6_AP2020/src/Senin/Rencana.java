package Senin;

import java.util.Scanner;

public class Rencana {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        // Preparation
        int Tabungan; // Rupiah
        int Libur; // Hari
        String Rencana = null;

// Input
        System.out.println("Masukkan nominal tabungan");
        Tabungan = scan.nextInt();

        System.out.println("Masukkan berapa hari liburnya");
        Libur = scan.nextInt();

// Output
        {
            if (Tabungan >= 50000000 && Libur > 14) {
                Rencana = "Ke Eropa";
                System.out.println("Adi berencana " + Rencana);
            } else if (20000000 < Tabungan && Tabungan < 50000000 && Libur > 14) {
                Rencana = "Ke Jepang";
                System.out.println("Adi berencana " + Rencana);
            } else if (Tabungan >= 50000000 && Libur <= 14) {
                Rencana = "Beli PS";
                System.out.println("Adi berencana " + Rencana);
            } else if (Tabungan < 5000000) {
                Rencana = "Kerja Sambilan";
                System.out.println("Adi berencana " + Rencana);
            }
        }
    }
}