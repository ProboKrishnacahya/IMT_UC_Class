/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Soal1 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int Tgl; // Tanggal
        int Bln; // Bulan
        int Thn; // Tahun

        System.out.println("Tanggal : ");
        Tgl = scan.nextInt();

        System.out.println("Bulan : ");
        Bln = scan.nextInt();

        System.out.println("Tahun : ");
        Thn = scan.nextInt();

        if (Tgl <= 0 || Tgl > 31) {
            System.out.println("Tanggal tidak valid");
        } else if (Bln <= 0 || Bln > 12) {
            System.out.println("Tanggal tidak valid");
        } else if (Bln == 1 || Bln == 3 || Bln == 5 || Bln == 7 || Bln == 8 || Bln == 10 || Bln == 12) {
            if (Tgl > 31) {
                System.out.println("Tanggal tidak valid");
            } else {
                System.out.println("Tanggal valid");
            }
        } else if (Bln == 4 || Bln == 6 || Bln == 9 || Bln == 11) {
            if (Tgl > 30) {
                System.out.println("Tanggal tidak valid");
            } else {
                System.out.println("Tanggal valid");
            }
        } else if (Thn % 400 == 0) {
            if (Tgl > 29) {
                System.out.println("Tanggal tidak valid");
            } else {
                System.out.println("Tanggal valid");
            }
        } else if (Thn % 100 == 0) {
            if (Tgl > 28) {
                System.out.println("Tanggal tidak valid");
            } else {
                System.out.println("Tanggal valid");
            }
        } else if (Thn % 4 == 0) {
            if (Tgl > 29) {
                System.out.println("Tanggal tidak valid");
            } else {
                System.out.println("Tanggal valid");
            }
        } else if (Tgl > 28) {
            System.out.println("Tanggal tidak valid");
        } else {
            System.out.println("Tanggal valid");
        }
    }
}
