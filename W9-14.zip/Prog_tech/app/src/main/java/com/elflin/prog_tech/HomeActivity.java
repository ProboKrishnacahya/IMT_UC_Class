package com.elflin.prog_tech;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import model.User;

public class HomeActivity extends AppCompatActivity {

    private Intent intent;
    private TextView main_cardDisplay_nama, main_cardDisplay_alamat, main_cardDisplay_jenisKelamin, main_cardDisplay_email;
    private Button home_button_logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        main_cardDisplay_nama = findViewById(R.id.main_cardDisplay_nama);
        main_cardDisplay_alamat = findViewById(R.id.main_cardDisplay_alamat);
        main_cardDisplay_jenisKelamin = findViewById(R.id.main_cardDisplay_jenisKelamin);
        main_cardDisplay_email = findViewById(R.id.main_cardDisplay_email);
        home_button_logout = findViewById(R.id.home_button_logout);

        intent = getIntent();

        // Cara Pertama
//        String nama = intent.getStringExtra("IDnama");
//        String alamat = intent.getStringExtra("IDalamat");
//        String jeniskelamin = intent.getStringExtra("IDjeniskelamin");
//        String email = intent.getStringExtra("IDemail");
//        String password = intent.getStringExtra("IDpassword");

        // Cara Kedua
        User user = intent.getParcelableExtra("IDuser");

        main_cardDisplay_nama.setText(user.getNama());
        main_cardDisplay_alamat.setText(user.getAlamat());
        main_cardDisplay_jenisKelamin.setText(user.getJenisKelamin());
        main_cardDisplay_email.setText(user.getEmail());

        home_button_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}