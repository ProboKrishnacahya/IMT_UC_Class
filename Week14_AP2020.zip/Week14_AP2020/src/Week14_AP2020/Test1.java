/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Week14_AP2020;

import java.util.Scanner;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class Test1 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        Test1 t = new Test1();

        t.tampilkanMenu();

        int angkaPertama = 0;
        int angkaKedua = 0;

        System.out.print("Masukkan angka pertama : ");
        angkaPertama = scan.nextInt();

        System.out.print("Masukkan angka kedua : ");
        angkaKedua = scan.nextInt();

        int hasil = t.penjumlahan(angkaPertama, angkaKedua) * 5500;
        int hasil1 = t.penjumlahan(hasil, angkaKedua);

        System.out.println("Hasil adalah " + hasil);
        System.out.println("Hasil adalah " + hasil1);

        System.out.println("Hasil pengurangan " + t.pengurangan(angkaKedua, angkaKedua));
    }

    public int penjumlahan(int x, int y) {
        int total = 0;
        int a = 100;
        int b = 400;
        total = x + y + a + b;
        System.out.println("total");
        return total;
    }

    public int pengurangan(int x, int y) {
        int total = 0;
        total = x - y;
        return total;
    }

    public void tampilkanMenu() {
        System.out.println("Menu");
        System.out.println("1. Penjumlahan");
        System.out.println("2. Pengurangan");
    }

    // Contoh
    public double[] testX(String[][] y) {
        double[] hasil = new double[10];
        return hasil;
    }
}
