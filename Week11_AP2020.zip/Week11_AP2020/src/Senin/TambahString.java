/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senin;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class TambahString {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Input : ");
        String input = scan.nextLine();
        int total = 0;

        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) >= '0' && input.charAt(i) <= '9') {
                total += Integer.parseInt(String.valueOf(input.charAt(i)));
            }
        }
        System.out.println("Output = " + total);
    }
}
